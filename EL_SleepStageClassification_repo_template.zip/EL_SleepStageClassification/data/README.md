
# data/ folder

**Do not commit raw data. / No subir datos crudos.**

## Sleep-EDFx download options
1) **Browser**: go to https://physionet.org/content/sleep-edfx/1.0.0/ and download the desired records.
2) **wget (example)**:
```bash
# Create local folder
mkdir -p data/sleep-edfx
# Example (adjust to specific files/URLs after logging in if required):
# wget -P data/sleep-edfx https://physionet.org/files/sleep-edfx/1.0.0/SC4001E0-PSG.edf
# wget -P data/sleep-edfx https://physionet.org/files/sleep-edfx/1.0.0/SC4001EC-Hypnogram.edf
```
3) **Python (sketch)**:
```python
import os, urllib.request
os.makedirs('data/sleep-edfx', exist_ok=True)
url = 'https://physionet.org/files/sleep-edfx/1.0.0/SC4001E0-PSG.edf'
dst = 'data/sleep-edfx/SC4001E0-PSG.edf'
urllib.request.urlretrieve(url, dst)
```

> Tip: PhysioNet may require an account/login for programmatic access. Keep credentials **outside** the repo.

## Expected local layout
```
data/
└─ sleep-edfx/
   ├─ <*.edf>
   └─ <hypnograms>
```
